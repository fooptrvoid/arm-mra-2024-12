<!-- Copyright (c) 2010-2024 Arm Limited or its affiliates. All rights reserved. -->
<!-- This document is Non-confidential and licensed under the BSD 3-clause license. -->
# Parameters

Parameters represent nodes in the $(Features) graph - they are items of data that the system knows
about. Constraints are edges that connect Parameters.

A given parameter has a name, and might have a domain of values attached to it. It may also
have constraints that affect its value - see $(Traits.HasConstraints) for more information.

